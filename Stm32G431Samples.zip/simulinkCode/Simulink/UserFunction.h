#ifndef _USERFUNCTION_H_
#define _USERFUNCTION_H_

#include "main.h"

float CalcCompensationTheta(float speed_rpm, float Delay_Ts, float Pole);


#endif