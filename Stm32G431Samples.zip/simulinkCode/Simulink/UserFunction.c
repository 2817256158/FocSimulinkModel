#include "UserFunction.h"
#include <math.h>

float CalcCompensationTheta(float speed_rpm, float Delay_Ts, float Pole)
{
    float comp_angle = 0.0f;
    float elec_omega = 0.0f;       // 电角速度(rad/s)
    
    // 1. 低速时关闭补偿（阈值可根据实际调试调整，例如<100rpm关闭）
    if(fabsf(speed_rpm) < 1000.0f)
    {
        return 0.0f;
    }
    
    // 2. 计算电角速度 ω_e = 2π * (n/60) * 极对数
    elec_omega = 2 * 3.14159f * (speed_rpm / 60.0f) * Pole;
    
    // 3. 计算滞后补偿角 = 电角速度 * 电流环周期
    comp_angle = elec_omega * Delay_Ts;
    
    return comp_angle;
}