/*
 * File: FOC_NLFO.c
 *
 * Code generated for Simulink model 'FOC_NLFO'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Jan 29 12:08:41 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "FOC_NLFO.h"
#include "rtwtypes.h"
#include "mw_cmsis.h"
#include <math.h>
#include <float.h>
#include "math.h"

/* Exported block signals */
real32_T Theta_ele;                    /* '<Root>/Theta_ele' */
real32_T PhaseCurrentA;                /* '<Root>/Cur_A' */
real32_T PhaseCurrentB;                /* '<Root>/Cur_B' */
real32_T PhaseCurrentC;                /* '<Root>/Cur_C' */
real32_T Gamma;                        /* '<Root>/Gamma' */
real32_T Pll_Kp;                       /* '<Root>/Pll_Kp' */
real32_T Pll_Ki;                       /* '<Root>/Pll_Ki' */
real32_T Speed_Target;                 /* '<Root>/Speed_Target' */
real32_T Mech_Speed;                   /* '<Root>/Mech_Speed' */
real32_T Speed_Kp;                     /* '<Root>/Speed_Kp' */
real32_T Speed_Ki;                     /* '<Root>/Speed_Ki' */
real32_T Cur_Kp;                       /* '<Root>/Cur_Kp' */
real32_T Cur_Ki;                       /* '<Root>/Cur_Ki' */
real32_T Id;                           /* '<S1>/Park' */
real32_T Iq;                           /* '<S1>/Park' */
real32_T Ta;                           /* '<S1>/Signal Conversion' */
real32_T Tb;                           /* '<S1>/Signal Conversion1' */
real32_T Tc;                           /* '<S1>/Signal Conversion2' */
real32_T Theta_Obs;                    /* '<S12>/Delay' */
real32_T Speed_Obs;                    /* '<S1>/Gain3' */

/* Block signals and states (default storage) */
DW rtDW;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;
extern real32_T rt_modf_snf(real32_T u0, real32_T u1);
static void InvPark(real32_T rtu_d, real32_T rtu_q, real32_T rtu_Theta, real32_T
                    *rty_alpha, real32_T *rty_beta);
static void Park(real32_T rtu_Alpha, real32_T rtu_Beta, real32_T rtu_Theta,
                 real32_T *rty_D, real32_T *rty_Q);
static void SVPWM(real32_T rtu_Ualpha, real32_T rtu_Ubeta, real32_T rtu_UBus,
                  real32_T rty_Tabc[3]);
static real_T rtGetNaN(void);
static real32_T rtGetNaNF(void);
extern real_T rtInf;
extern real_T rtMinusInf;
extern real_T rtNaN;
extern real32_T rtInfF;
extern real32_T rtMinusInfF;
extern real32_T rtNaNF;
static boolean_T rtIsInf(real_T value);
static boolean_T rtIsInfF(real32_T value);
static boolean_T rtIsNaN(real_T value);
static boolean_T rtIsNaNF(real32_T value);
real_T rtNaN = -(real_T)NAN;
real_T rtInf = (real_T)INFINITY;
real_T rtMinusInf = -(real_T)INFINITY;
real32_T rtNaNF = -(real32_T)NAN;
real32_T rtInfF = (real32_T)INFINITY;
real32_T rtMinusInfF = -(real32_T)INFINITY;

/* Return rtNaN needed by the generated code. */
static real_T rtGetNaN(void)
{
  return rtNaN;
}

/* Return rtNaNF needed by the generated code. */
static real32_T rtGetNaNF(void)
{
  return rtNaNF;
}

/* Test if value is infinite */
static boolean_T rtIsInf(real_T value)
{
  return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
}

/* Test if single-precision value is infinite */
static boolean_T rtIsInfF(real32_T value)
{
  return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
}

/* Test if value is not a number */
static boolean_T rtIsNaN(real_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/* Test if single-precision value is not a number */
static boolean_T rtIsNaNF(real32_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/* Output and update for atomic system: '<S1>/InvPark' */
static void InvPark(real32_T rtu_d, real32_T rtu_q, real32_T rtu_Theta, real32_T
                    *rty_alpha, real32_T *rty_beta)
{
  real32_T rtb_Sin1_f;

  /* Trigonometry: '<S4>/Sin1' */
  rtb_Sin1_f = arm_cos_f32(rtu_Theta);

  /* Trigonometry: '<S4>/Sin' */
  *rty_beta = arm_sin_f32(rtu_Theta);

  /* Sum: '<S4>/Sum' incorporates:
   *  Product: '<S4>/Product'
   *  Product: '<S4>/Product1'
   */
  *rty_alpha = rtu_d * rtb_Sin1_f - rtu_q * *rty_beta;

  /* Sum: '<S4>/Sum1' incorporates:
   *  Product: '<S4>/Product2'
   *  Product: '<S4>/Product3'
   */
  *rty_beta = rtu_d * *rty_beta + rtu_q * rtb_Sin1_f;
}

/* Output and update for atomic system: '<S1>/Park' */
static void Park(real32_T rtu_Alpha, real32_T rtu_Beta, real32_T rtu_Theta,
                 real32_T *rty_D, real32_T *rty_Q)
{
  real32_T rtb_Sin1_m;

  /* Trigonometry: '<S5>/Sin1' */
  rtb_Sin1_m = arm_cos_f32(rtu_Theta);

  /* Trigonometry: '<S5>/Sin' */
  *rty_Q = arm_sin_f32(rtu_Theta);

  /* Sum: '<S5>/Sum' incorporates:
   *  Product: '<S5>/Product'
   *  Product: '<S5>/Product1'
   */
  *rty_D = rtu_Alpha * rtb_Sin1_m + rtu_Beta * *rty_Q;

  /* Sum: '<S5>/Sum1' incorporates:
   *  Product: '<S5>/Product2'
   *  Product: '<S5>/Product3'
   */
  *rty_Q = rtu_Beta * rtb_Sin1_m - rtu_Alpha * *rty_Q;
}

/* Output and update for atomic system: '<S1>/SVPWM' */
static void SVPWM(real32_T rtu_Ualpha, real32_T rtu_Ubeta, real32_T rtu_UBus,
                  real32_T rty_Tabc[3])
{
  real32_T tmp[3];
  real32_T rtb_Min;
  real32_T rtb_Sum1_g;
  real32_T rtb_Sum_c;

  /* Gain: '<S67>/Gain' */
  rtb_Min = -0.5F * rtu_Ualpha;

  /* Gain: '<S67>/Gain1' */
  rtb_Sum1_g = 0.866025388F * rtu_Ubeta;

  /* Sum: '<S67>/Sum' */
  rtb_Sum_c = rtb_Min + rtb_Sum1_g;

  /* Sum: '<S67>/Sum1' */
  rtb_Sum1_g = rtb_Min - rtb_Sum1_g;

  /* Gain: '<S68>/Gain' incorporates:
   *  MinMax: '<S68>/Min'
   *  MinMax: '<S68>/Min1'
   *  Sum: '<S68>/Sum'
   */
  rtb_Min = (fminf(fminf(rtu_Ualpha, rtb_Sum_c), rtb_Sum1_g) + fmaxf(fmaxf
              (rtu_Ualpha, rtb_Sum_c), rtb_Sum1_g)) * -0.5F;

  /* Sum: '<S6>/Sum' */
  rty_Tabc[0] = rtb_Min + rtu_Ualpha;
  rty_Tabc[1] = rtb_Min + rtb_Sum_c;
  rty_Tabc[2] = rtb_Min + rtb_Sum1_g;

  /* Gain: '<S6>/Gain' */
  mw_arm_scale_1_f32(&rtConstP.Gain_Gain_l, &rty_Tabc[0], &tmp[0], 3U);

  /* Sum: '<S6>/Sum1' incorporates:
   *  Constant: '<S6>/Constant'
   *  Gain: '<S6>/Gain'
   *  Product: '<S6>/Divide'
   */
  tmp[0] /= rtu_UBus;
  tmp[1] /= rtu_UBus;
  tmp[2] /= rtu_UBus;
  mw_arm_bias_2_f32(&tmp[0], &rtConstP.pooled1, &rty_Tabc[0], 3U);
}

real32_T rt_modf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  y = u0;
  if (u1 == 0.0F) {
    if (u0 == 0.0F) {
      y = u1;
    }
  } else if (rtIsNaNF(u0) || rtIsNaNF(u1) || rtIsInfF(u0)) {
    y = (rtNaNF);
  } else if (u0 == 0.0F) {
    y = 0.0F / u1;
  } else if (rtIsInfF(u1)) {
    if ((u1 < 0.0F) != (u0 < 0.0F)) {
      y = u1;
    }
  } else {
    boolean_T yEq;
    y = fmodf(u0, u1);
    yEq = (y == 0.0F);
    if ((!yEq) && (u1 > floorf(u1))) {
      real32_T q;
      q = fabsf(u0 / u1);
      yEq = !(fabsf(q - floorf(q + 0.5F)) > FLT_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0F;
    } else if ((u0 < 0.0F) != (u1 < 0.0F)) {
      y += u1;
    }
  }

  return y;
}

/* Model step function */
void FOC_NLFO_step(void)
{
  real32_T rtb_ARR[3];
  real32_T rtb_ARR_0[3];
  real32_T rtb_DeadZone;
  real32_T rtb_DeadZone_g;
  real32_T rtb_E;
  real32_T rtb_E_o;
  real32_T rtb_Gain;
  real32_T rtb_Gain2_k;
  real32_T rtb_IProdOut_d;
  real32_T rtb_IProdOut_h;
  real32_T rtb_Integrator_c;
  real32_T rtb_Saturation;
  real32_T rtb_Sum1;
  real32_T rtb_Sum1_f;
  real32_T rtb_Sum_k;
  int8_T tmp;
  int8_T tmp_0;

  /* Outputs for Atomic SubSystem: '<Root>/FOC_NLFO' */
  /* Saturate: '<S1>/Saturation' incorporates:
   *  Inport: '<Root>/Theta_ele'
   */
  if (Theta_ele > 6.28218508F) {
    rtb_Saturation = 6.28218508F;
  } else if (Theta_ele < -6.28218508F) {
    rtb_Saturation = -6.28218508F;
  } else {
    rtb_Saturation = Theta_ele;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* Outputs for Atomic SubSystem: '<S1>/Clark' */
  /* Gain: '<S2>/Gain' incorporates:
   *  Gain: '<S2>/Gain1'
   *  Inport: '<Root>/Cur_A'
   *  Inport: '<Root>/Cur_B'
   *  Inport: '<Root>/Cur_C'
   *  Sum: '<S2>/Sum'
   *  Sum: '<S2>/Sum1'
   */
  rtb_Gain = (PhaseCurrentA - (PhaseCurrentB + PhaseCurrentC) * 0.5F) *
    0.666666687F;

  /* Gain: '<S2>/Gain2' incorporates:
   *  Inport: '<Root>/Cur_B'
   *  Inport: '<Root>/Cur_C'
   *  Sum: '<S2>/Sum2'
   */
  rtb_Gain2_k = (PhaseCurrentB - PhaseCurrentC) * 0.577350259F;

  /* End of Outputs for SubSystem: '<S1>/Clark' */

  /* Outputs for Atomic SubSystem: '<S1>/Park' */
  /* SignalConversion generated from: '<S1>/Park' */
  Park(rtb_Gain, rtb_Gain2_k, rtb_Saturation, &Id, &Iq);

  /* End of Outputs for SubSystem: '<S1>/Park' */

  /* Sum: '<S167>/Sum' incorporates:
   *  Constant: '<S1>/Constant1'
   *  DiscreteIntegrator: '<S158>/Integrator'
   *  Inport: '<Root>/Cur_Kp'
   *  Product: '<S163>/PProd Out'
   *  Sum: '<S7>/Sum1'
   */
  rtb_DeadZone = (0.0F - Id) * Cur_Kp + rtDW.Integrator_DSTATE;

  /* Sum: '<S8>/Sum' incorporates:
   *  Inport: '<Root>/Mech_Speed'
   *  Inport: '<Root>/Speed_Target'
   */
  rtb_Sum_k = Speed_Target - Mech_Speed;

  /* Sum: '<S218>/Sum' incorporates:
   *  DiscreteIntegrator: '<S209>/Integrator'
   *  Inport: '<Root>/Speed_Kp'
   *  Product: '<S214>/PProd Out'
   */
  rtb_IProdOut_d = rtb_Sum_k * Speed_Kp + rtDW.Integrator_DSTATE_l;

  /* Saturate: '<S216>/Saturation' */
  if (rtb_IProdOut_d > 10.0F) {
    rtb_IProdOut_d = 10.0F;
  } else if (rtb_IProdOut_d < -10.0F) {
    rtb_IProdOut_d = -10.0F;
  }

  /* Sum: '<S7>/Sum' incorporates:
   *  Saturate: '<S216>/Saturation'
   */
  rtb_IProdOut_d -= Iq;

  /* Sum: '<S115>/Sum' incorporates:
   *  DiscreteIntegrator: '<S106>/Integrator'
   *  Inport: '<Root>/Cur_Kp'
   *  Product: '<S111>/PProd Out'
   */
  rtb_DeadZone_g = rtb_IProdOut_d * Cur_Kp + rtDW.Integrator_DSTATE_j;

  /* Saturate: '<S165>/Saturation' */
  if (rtb_DeadZone > 6.0F) {
    rtb_Integrator_c = 6.0F;
  } else if (rtb_DeadZone < -6.0F) {
    rtb_Integrator_c = -6.0F;
  } else {
    rtb_Integrator_c = rtb_DeadZone;
  }

  /* Saturate: '<S113>/Saturation' */
  if (rtb_DeadZone_g > 6.0F) {
    rtb_E = 6.0F;
  } else if (rtb_DeadZone_g < -6.0F) {
    rtb_E = -6.0F;
  } else {
    rtb_E = rtb_DeadZone_g;
  }

  /* Outputs for Atomic SubSystem: '<S1>/InvPark' */
  /* Saturate: '<S165>/Saturation' incorporates:
   *  Saturate: '<S113>/Saturation'
   */
  InvPark(rtb_Integrator_c, rtb_E, rtb_Saturation, &rtb_IProdOut_h, &rtb_Sum1_f);

  /* End of Outputs for SubSystem: '<S1>/InvPark' */

  /* Outputs for Atomic SubSystem: '<S1>/SVPWM' */
  /* Constant: '<S1>/Constant' */
  SVPWM(rtb_IProdOut_h, rtb_Sum1_f, 12.0F, rtb_ARR);

  /* End of Outputs for SubSystem: '<S1>/SVPWM' */

  /* Gain: '<S1>/ARR' */
  mw_arm_scale_1_f32(&rtConstP.ARR_Gain, &rtb_ARR[0], &rtb_ARR_0[0], 3U);

  /* SignalConversion: '<S1>/Signal Conversion' incorporates:
   *  Gain: '<S1>/ARR'
   */
  Ta = rtb_ARR_0[0];

  /* SignalConversion: '<S1>/Signal Conversion1' incorporates:
   *  Gain: '<S1>/ARR'
   */
  Tb = rtb_ARR_0[1];

  /* SignalConversion: '<S1>/Signal Conversion2' incorporates:
   *  Gain: '<S1>/ARR'
   */
  Tc = rtb_ARR_0[2];

  /* Sum: '<S3>/Add4' incorporates:
   *  Gain: '<S3>/Gain'
   */
  rtb_Saturation = (0.0F - 0.082F * rtb_Gain) + rtb_IProdOut_h;

  /* Sum: '<S3>/Sum' incorporates:
   *  DiscreteIntegrator: '<S3>/Integrator2'
   *  Gain: '<S3>/Gain2'
   */
  rtb_Gain = rtDW.Integrator2_DSTATE - 5.135E-5F * rtb_Gain;

  /* Sum: '<S3>/Sum1' incorporates:
   *  DiscreteIntegrator: '<S3>/Integrator1'
   *  Gain: '<S3>/Gain3'
   */
  rtb_Integrator_c = rtDW.Integrator1_DSTATE - 5.167E-5F * rtb_Gain2_k;

  /* Sum: '<S3>/Add2' incorporates:
   *  Math: '<S3>/Math Function'
   *  Math: '<S3>/Math Function1'
   *
   * About '<S3>/Math Function':
   *  Operator: magnitude^2
   *
   * About '<S3>/Math Function1':
   *  Operator: magnitude^2
   */
  rtb_IProdOut_h = (1.06092057E-6F - rtb_Gain * rtb_Gain) - rtb_Integrator_c *
    rtb_Integrator_c;

  /* Product: '<S3>/Product' incorporates:
   *  Inport: '<Root>/Gamma'
   */
  rtb_E = rtb_Gain * rtb_IProdOut_h * Gamma;

  /* Product: '<S3>/Product1' incorporates:
   *  Inport: '<Root>/Gamma'
   */
  rtb_E_o = Gamma * rtb_IProdOut_h * rtb_Integrator_c;

  /* Delay: '<S12>/Delay' */
  Theta_Obs = rtDW.Delay_DSTATE;

  /* Math: '<S9>/Math Function' incorporates:
   *  Constant: '<S9>/Constant4'
   */
  rtb_IProdOut_h = rt_modf_snf(Theta_Obs, 6.28318548F);

  /* MATLAB Function: '<S9>/MATLAB Function' incorporates:
   *  Constant: '<S9>/Constant1'
   */
  if (rtb_IProdOut_h >= 6.28218508F) {
    rtb_IProdOut_h = 6.28218508F;
  }

  /* End of MATLAB Function: '<S9>/MATLAB Function' */

  /* Sum: '<S9>/Sum' incorporates:
   *  Product: '<S9>/Product'
   *  Product: '<S9>/Product1'
   *  Trigonometry: '<S9>/Sin'
   *  Trigonometry: '<S9>/Sin1'
   */
  rtb_IProdOut_h = rtb_Integrator_c * cosf(rtb_IProdOut_h) - sinf(rtb_IProdOut_h)
    * rtb_Gain;

  /* Sum: '<S57>/Sum' incorporates:
   *  DiscreteIntegrator: '<S48>/Integrator'
   *  Inport: '<Root>/Pll_Kp'
   *  Product: '<S53>/PProd Out'
   */
  rtb_Gain = rtb_IProdOut_h * Pll_Kp + rtDW.Integrator_DSTATE_o;

  /* DeadZone: '<S40>/DeadZone' incorporates:
   *  Saturate: '<S55>/Saturation'
   */
  if (rtb_Gain > 5864.30615F) {
    rtb_Integrator_c = rtb_Gain - 5864.30615F;
    rtb_Gain = 5864.30615F;
  } else {
    if (rtb_Gain >= -5864.30615F) {
      rtb_Integrator_c = 0.0F;
    } else {
      rtb_Integrator_c = rtb_Gain - -5864.30615F;
    }

    if (rtb_Gain < -5864.30615F) {
      rtb_Gain = -5864.30615F;
    }
  }

  /* End of DeadZone: '<S40>/DeadZone' */

  /* Product: '<S45>/IProd Out' incorporates:
   *  Inport: '<Root>/Pll_Ki'
   */
  rtb_IProdOut_h *= Pll_Ki;

  /* Sum: '<S12>/Sum1' incorporates:
   *  Gain: '<S12>/Ts'
   */
  rtb_Sum1 = 5.0E-5F * rtb_Gain + Theta_Obs;

  /* Gain: '<S1>/Gain3' */
  Speed_Obs = 1.36418521F * rtb_Gain;

  /* DeadZone: '<S98>/DeadZone' */
  if (rtb_DeadZone_g > 6.0F) {
    rtb_DeadZone_g -= 6.0F;
  } else if (rtb_DeadZone_g >= -6.0F) {
    rtb_DeadZone_g = 0.0F;
  } else {
    rtb_DeadZone_g -= -6.0F;
  }

  /* End of DeadZone: '<S98>/DeadZone' */

  /* Product: '<S103>/IProd Out' incorporates:
   *  Inport: '<Root>/Cur_Ki'
   */
  rtb_IProdOut_d *= Cur_Ki;

  /* DeadZone: '<S150>/DeadZone' */
  if (rtb_DeadZone > 6.0F) {
    rtb_DeadZone -= 6.0F;
  } else if (rtb_DeadZone >= -6.0F) {
    rtb_DeadZone = 0.0F;
  } else {
    rtb_DeadZone -= -6.0F;
  }

  /* End of DeadZone: '<S150>/DeadZone' */

  /* Product: '<S155>/IProd Out' incorporates:
   *  Constant: '<S1>/Constant1'
   *  Inport: '<Root>/Cur_Ki'
   *  Sum: '<S7>/Sum1'
   */
  rtb_Gain = (0.0F - Id) * Cur_Ki;

  /* Switch: '<S148>/Switch1' incorporates:
   *  Constant: '<S148>/Clamping_zero'
   *  Constant: '<S148>/Constant'
   *  Constant: '<S148>/Constant2'
   *  RelationalOperator: '<S148>/fix for DT propagation issue'
   */
  if (rtb_DeadZone > 0.0F) {
    tmp = 1;
  } else {
    tmp = -1;
  }

  /* Switch: '<S148>/Switch2' incorporates:
   *  Constant: '<S148>/Clamping_zero'
   *  Constant: '<S148>/Constant3'
   *  Constant: '<S148>/Constant4'
   *  RelationalOperator: '<S148>/fix for DT propagation issue1'
   */
  if (rtb_Gain > 0.0F) {
    tmp_0 = 1;
  } else {
    tmp_0 = -1;
  }

  /* Switch: '<S148>/Switch' incorporates:
   *  Constant: '<S148>/Clamping_zero'
   *  Constant: '<S148>/Constant1'
   *  Logic: '<S148>/AND3'
   *  RelationalOperator: '<S148>/Equal1'
   *  RelationalOperator: '<S148>/Relational Operator'
   *  Switch: '<S148>/Switch1'
   *  Switch: '<S148>/Switch2'
   */
  if ((rtb_DeadZone != 0.0F) && (tmp == tmp_0)) {
    rtb_Gain = 0.0F;
  }

  /* Update for DiscreteIntegrator: '<S158>/Integrator' incorporates:
   *  Switch: '<S148>/Switch'
   */
  rtDW.Integrator_DSTATE += 0.0001F * rtb_Gain;

  /* Update for DiscreteIntegrator: '<S209>/Integrator' incorporates:
   *  Inport: '<Root>/Speed_Ki'
   *  Product: '<S206>/IProd Out'
   */
  rtDW.Integrator_DSTATE_l += rtb_Sum_k * Speed_Ki * 0.0001F;

  /* Switch: '<S96>/Switch1' incorporates:
   *  Constant: '<S96>/Clamping_zero'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S96>/Constant2'
   *  RelationalOperator: '<S96>/fix for DT propagation issue'
   */
  if (rtb_DeadZone_g > 0.0F) {
    tmp = 1;
  } else {
    tmp = -1;
  }

  /* Switch: '<S96>/Switch2' incorporates:
   *  Constant: '<S96>/Clamping_zero'
   *  Constant: '<S96>/Constant3'
   *  Constant: '<S96>/Constant4'
   *  RelationalOperator: '<S96>/fix for DT propagation issue1'
   */
  if (rtb_IProdOut_d > 0.0F) {
    tmp_0 = 1;
  } else {
    tmp_0 = -1;
  }

  /* Switch: '<S96>/Switch' incorporates:
   *  Constant: '<S96>/Clamping_zero'
   *  Constant: '<S96>/Constant1'
   *  Logic: '<S96>/AND3'
   *  RelationalOperator: '<S96>/Equal1'
   *  RelationalOperator: '<S96>/Relational Operator'
   *  Switch: '<S96>/Switch1'
   *  Switch: '<S96>/Switch2'
   */
  if ((rtb_DeadZone_g != 0.0F) && (tmp == tmp_0)) {
    rtb_IProdOut_d = 0.0F;
  }

  /* Update for DiscreteIntegrator: '<S106>/Integrator' incorporates:
   *  Switch: '<S96>/Switch'
   */
  rtDW.Integrator_DSTATE_j += 0.0001F * rtb_IProdOut_d;

  /* Update for DiscreteIntegrator: '<S3>/Integrator2' incorporates:
   *  Sum: '<S3>/Add'
   */
  rtDW.Integrator2_DSTATE += (rtb_Saturation + rtb_E) * 0.0001F;

  /* Update for DiscreteIntegrator: '<S3>/Integrator1' incorporates:
   *  Gain: '<S3>/Gain4'
   *  Sum: '<S3>/Add1'
   *  Sum: '<S3>/Add5'
   */
  rtDW.Integrator1_DSTATE += ((rtb_Sum1_f - 0.082F * rtb_Gain2_k) + rtb_E_o) *
    0.0001F;

  /* MATLAB Function: '<S65>/MATLAB Function' */
  if (rtb_Sum1 >= 6.2831853071795862) {
    /* Update for Delay: '<S12>/Delay' */
    rtDW.Delay_DSTATE = rtb_Sum1 - 6.28318548F;
  } else if (rtb_Sum1 <= 0.0F) {
    /* Update for Delay: '<S12>/Delay' */
    rtDW.Delay_DSTATE = rtb_Sum1 + 6.28318548F;
  } else {
    /* Update for Delay: '<S12>/Delay' */
    rtDW.Delay_DSTATE = rtb_Sum1;
  }

  /* End of MATLAB Function: '<S65>/MATLAB Function' */

  /* Switch: '<S38>/Switch1' incorporates:
   *  Constant: '<S38>/Clamping_zero'
   *  Constant: '<S38>/Constant'
   *  Constant: '<S38>/Constant2'
   *  RelationalOperator: '<S38>/fix for DT propagation issue'
   */
  if (rtb_Integrator_c > 0.0F) {
    tmp = 1;
  } else {
    tmp = -1;
  }

  /* Switch: '<S38>/Switch2' incorporates:
   *  Constant: '<S38>/Clamping_zero'
   *  Constant: '<S38>/Constant3'
   *  Constant: '<S38>/Constant4'
   *  RelationalOperator: '<S38>/fix for DT propagation issue1'
   */
  if (rtb_IProdOut_h > 0.0F) {
    tmp_0 = 1;
  } else {
    tmp_0 = -1;
  }

  /* Switch: '<S38>/Switch' incorporates:
   *  Constant: '<S38>/Clamping_zero'
   *  Constant: '<S38>/Constant1'
   *  Logic: '<S38>/AND3'
   *  RelationalOperator: '<S38>/Equal1'
   *  RelationalOperator: '<S38>/Relational Operator'
   *  Switch: '<S38>/Switch1'
   *  Switch: '<S38>/Switch2'
   */
  if ((rtb_Integrator_c != 0.0F) && (tmp == tmp_0)) {
    rtb_IProdOut_h = 0.0F;
  }

  /* Update for DiscreteIntegrator: '<S48>/Integrator' incorporates:
   *  Switch: '<S38>/Switch'
   */
  rtDW.Integrator_DSTATE_o += 0.0001F * rtb_IProdOut_h;

  /* End of Outputs for SubSystem: '<Root>/FOC_NLFO' */
}

/* Model initialize function */
void FOC_NLFO_initialize(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
