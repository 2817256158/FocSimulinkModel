/*
 * File: FOC_NLFO_data.c
 *
 * Code generated for Simulink model 'FOC_NLFO'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Jan 29 12:08:41 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "FOC_NLFO.h"

/* Constant parameters (default storage) */
const ConstP rtConstP = {
  /* Pooled Parameter (Expression: 0.5)
   * Referenced by:
   *   '<S2>/Gain1'
   *   '<S6>/Constant'
   */
  0.5F,

  /* Computed Parameter: Gain_Gain_l
   * Referenced by: '<S6>/Gain'
   */
  -1.0F,

  /* Computed Parameter: ARR_Gain
   * Referenced by: '<S1>/ARR'
   */
  4200.0F
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
