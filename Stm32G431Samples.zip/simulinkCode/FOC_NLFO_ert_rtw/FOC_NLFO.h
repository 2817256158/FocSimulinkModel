/*
 * File: FOC_NLFO.h
 *
 * Code generated for Simulink model 'FOC_NLFO'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Jan 29 12:08:41 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef FOC_NLFO_h_
#define FOC_NLFO_h_
#ifndef FOC_NLFO_COMMON_INCLUDES_
#define FOC_NLFO_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "math.h"
#endif                                 /* FOC_NLFO_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real32_T Integrator_DSTATE;          /* '<S158>/Integrator' */
  real32_T Integrator_DSTATE_l;        /* '<S209>/Integrator' */
  real32_T Integrator_DSTATE_j;        /* '<S106>/Integrator' */
  real32_T Integrator2_DSTATE;         /* '<S3>/Integrator2' */
  real32_T Integrator1_DSTATE;         /* '<S3>/Integrator1' */
  real32_T Delay_DSTATE;               /* '<S12>/Delay' */
  real32_T Integrator_DSTATE_o;        /* '<S48>/Integrator' */
} DW;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: 0.5)
   * Referenced by:
   *   '<S2>/Gain1'
   *   '<S6>/Constant'
   */
  real32_T pooled1;

  /* Computed Parameter: Gain_Gain_l
   * Referenced by: '<S6>/Gain'
   */
  real32_T Gain_Gain_l;

  /* Computed Parameter: ARR_Gain
   * Referenced by: '<S1>/ARR'
   */
  real32_T ARR_Gain;
} ConstP;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T * volatile errorStatus;
};

/* Block signals and states (default storage) */
extern DW rtDW;

/* Constant parameters (default storage) */
extern const ConstP rtConstP;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern real32_T Theta_ele;             /* '<Root>/Theta_ele' */
extern real32_T PhaseCurrentA;         /* '<Root>/Cur_A' */
extern real32_T PhaseCurrentB;         /* '<Root>/Cur_B' */
extern real32_T PhaseCurrentC;         /* '<Root>/Cur_C' */
extern real32_T Gamma;                 /* '<Root>/Gamma' */
extern real32_T Pll_Kp;                /* '<Root>/Pll_Kp' */
extern real32_T Pll_Ki;                /* '<Root>/Pll_Ki' */
extern real32_T Speed_Target;          /* '<Root>/Speed_Target' */
extern real32_T Mech_Speed;            /* '<Root>/Mech_Speed' */
extern real32_T Speed_Kp;              /* '<Root>/Speed_Kp' */
extern real32_T Speed_Ki;              /* '<Root>/Speed_Ki' */
extern real32_T Cur_Kp;                /* '<Root>/Cur_Kp' */
extern real32_T Cur_Ki;                /* '<Root>/Cur_Ki' */
extern real32_T Id;                    /* '<S1>/Park' */
extern real32_T Iq;                    /* '<S1>/Park' */
extern real32_T Ta;                    /* '<S1>/Signal Conversion' */
extern real32_T Tb;                    /* '<S1>/Signal Conversion1' */
extern real32_T Tc;                    /* '<S1>/Signal Conversion2' */
extern real32_T Theta_Obs;             /* '<S12>/Delay' */
extern real32_T Speed_Obs;             /* '<S1>/Gain3' */

/* Model entry point functions */
extern void FOC_NLFO_initialize(void);
extern void FOC_NLFO_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Display' : Unused code path elimination
 * Block '<S3>/Scope' : Unused code path elimination
 * Block '<S3>/Scope1' : Unused code path elimination
 * Block '<S3>/Scope10' : Unused code path elimination
 * Block '<S3>/Scope11' : Unused code path elimination
 * Block '<S3>/Scope2' : Unused code path elimination
 * Block '<S3>/Scope4' : Unused code path elimination
 * Block '<S3>/Scope5' : Unused code path elimination
 * Block '<S3>/Scope7' : Unused code path elimination
 * Block '<S3>/Scope8' : Unused code path elimination
 * Block '<S3>/Scope9' : Unused code path elimination
 * Block '<S1>/Scope10' : Unused code path elimination
 * Block '<S1>/Scope11' : Unused code path elimination
 * Block '<S1>/Scope20' : Unused code path elimination
 * Block '<S1>/Scope3' : Unused code path elimination
 * Block '<S1>/Scope4' : Unused code path elimination
 * Block '<S1>/Scope5' : Unused code path elimination
 * Block '<S1>/Scope6' : Unused code path elimination
 * Block '<S1>/Scope8' : Unused code path elimination
 * Block '<S1>/Rate Transition' : Eliminated since input and output rates are identical
 * Block '<S1>/Signal Conversion3' : Eliminate redundant signal conversion block
 * Block '<S1>/Signal Conversion4' : Eliminate redundant signal conversion block
 * Block '<S1>/Signal Conversion5' : Eliminate redundant signal conversion block
 * Block '<S1>/Signal Conversion6' : Eliminate redundant signal conversion block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('NLFO_CodeGenerator/FOC_NLFO')    - opens subsystem NLFO_CodeGenerator/FOC_NLFO
 * hilite_system('NLFO_CodeGenerator/FOC_NLFO/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'NLFO_CodeGenerator'
 * '<S1>'   : 'NLFO_CodeGenerator/FOC_NLFO'
 * '<S2>'   : 'NLFO_CodeGenerator/FOC_NLFO/Clark'
 * '<S3>'   : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer'
 * '<S4>'   : 'NLFO_CodeGenerator/FOC_NLFO/InvPark'
 * '<S5>'   : 'NLFO_CodeGenerator/FOC_NLFO/Park'
 * '<S6>'   : 'NLFO_CodeGenerator/FOC_NLFO/SVPWM'
 * '<S7>'   : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1'
 * '<S8>'   : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2'
 * '<S9>'   : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL'
 * '<S10>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller'
 * '<S11>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/MATLAB Function'
 * '<S12>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/integrator'
 * '<S13>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Anti-windup'
 * '<S14>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/D Gain'
 * '<S15>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/External Derivative'
 * '<S16>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Filter'
 * '<S17>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Filter ICs'
 * '<S18>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/I Gain'
 * '<S19>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Ideal P Gain'
 * '<S20>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Ideal P Gain Fdbk'
 * '<S21>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Integrator'
 * '<S22>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Integrator ICs'
 * '<S23>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/N Copy'
 * '<S24>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/N Gain'
 * '<S25>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/P Copy'
 * '<S26>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Parallel P Gain'
 * '<S27>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Reset Signal'
 * '<S28>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Saturation'
 * '<S29>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Saturation Fdbk'
 * '<S30>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Sum'
 * '<S31>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Sum Fdbk'
 * '<S32>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tracking Mode'
 * '<S33>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tracking Mode Sum'
 * '<S34>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tsamp - Integral'
 * '<S35>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tsamp - Ngain'
 * '<S36>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/postSat Signal'
 * '<S37>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/preSat Signal'
 * '<S38>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel'
 * '<S39>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
 * '<S40>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
 * '<S41>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/D Gain/Disabled'
 * '<S42>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/External Derivative/Disabled'
 * '<S43>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Filter/Disabled'
 * '<S44>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Filter ICs/Disabled'
 * '<S45>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/I Gain/External Parameters'
 * '<S46>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Ideal P Gain/Passthrough'
 * '<S47>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S48>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Integrator/Discrete'
 * '<S49>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Integrator ICs/Internal IC'
 * '<S50>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/N Copy/Disabled wSignal Specification'
 * '<S51>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/N Gain/Disabled'
 * '<S52>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/P Copy/Disabled'
 * '<S53>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Parallel P Gain/External Parameters'
 * '<S54>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Reset Signal/Disabled'
 * '<S55>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Saturation/Enabled'
 * '<S56>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Saturation Fdbk/Disabled'
 * '<S57>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Sum/Sum_PI'
 * '<S58>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Sum Fdbk/Disabled'
 * '<S59>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tracking Mode/Disabled'
 * '<S60>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tracking Mode Sum/Passthrough'
 * '<S61>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tsamp - Integral/TsSignalSpecification'
 * '<S62>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/Tsamp - Ngain/Passthrough'
 * '<S63>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/postSat Signal/Forward_Path'
 * '<S64>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/Discrete PID Controller/preSat Signal/Forward_Path'
 * '<S65>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/integrator/Angle_Limit'
 * '<S66>'  : 'NLFO_CodeGenerator/FOC_NLFO/Effective_Flux_Observer/PLL/integrator/Angle_Limit/MATLAB Function'
 * '<S67>'  : 'NLFO_CodeGenerator/FOC_NLFO/SVPWM/InvClark'
 * '<S68>'  : 'NLFO_CodeGenerator/FOC_NLFO/SVPWM/ei_t'
 * '<S69>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller'
 * '<S70>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1'
 * '<S71>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Anti-windup'
 * '<S72>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/D Gain'
 * '<S73>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/External Derivative'
 * '<S74>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Filter'
 * '<S75>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Filter ICs'
 * '<S76>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/I Gain'
 * '<S77>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Ideal P Gain'
 * '<S78>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Ideal P Gain Fdbk'
 * '<S79>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Integrator'
 * '<S80>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Integrator ICs'
 * '<S81>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/N Copy'
 * '<S82>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/N Gain'
 * '<S83>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/P Copy'
 * '<S84>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Parallel P Gain'
 * '<S85>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Reset Signal'
 * '<S86>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Saturation'
 * '<S87>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Saturation Fdbk'
 * '<S88>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Sum'
 * '<S89>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Sum Fdbk'
 * '<S90>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tracking Mode'
 * '<S91>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tracking Mode Sum'
 * '<S92>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tsamp - Integral'
 * '<S93>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tsamp - Ngain'
 * '<S94>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/postSat Signal'
 * '<S95>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/preSat Signal'
 * '<S96>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel'
 * '<S97>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
 * '<S98>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
 * '<S99>'  : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/D Gain/Disabled'
 * '<S100>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/External Derivative/Disabled'
 * '<S101>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Filter/Disabled'
 * '<S102>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Filter ICs/Disabled'
 * '<S103>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/I Gain/External Parameters'
 * '<S104>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Ideal P Gain/Passthrough'
 * '<S105>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S106>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Integrator/Discrete'
 * '<S107>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Integrator ICs/Internal IC'
 * '<S108>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/N Copy/Disabled wSignal Specification'
 * '<S109>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/N Gain/Disabled'
 * '<S110>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/P Copy/Disabled'
 * '<S111>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Parallel P Gain/External Parameters'
 * '<S112>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Reset Signal/Disabled'
 * '<S113>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Saturation/Enabled'
 * '<S114>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Saturation Fdbk/Disabled'
 * '<S115>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Sum/Sum_PI'
 * '<S116>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Sum Fdbk/Disabled'
 * '<S117>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tracking Mode/Disabled'
 * '<S118>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tracking Mode Sum/Passthrough'
 * '<S119>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tsamp - Integral/TsSignalSpecification'
 * '<S120>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/Tsamp - Ngain/Passthrough'
 * '<S121>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/postSat Signal/Forward_Path'
 * '<S122>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller/preSat Signal/Forward_Path'
 * '<S123>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Anti-windup'
 * '<S124>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/D Gain'
 * '<S125>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/External Derivative'
 * '<S126>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Filter'
 * '<S127>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Filter ICs'
 * '<S128>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/I Gain'
 * '<S129>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Ideal P Gain'
 * '<S130>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Ideal P Gain Fdbk'
 * '<S131>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Integrator'
 * '<S132>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Integrator ICs'
 * '<S133>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/N Copy'
 * '<S134>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/N Gain'
 * '<S135>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/P Copy'
 * '<S136>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Parallel P Gain'
 * '<S137>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Reset Signal'
 * '<S138>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Saturation'
 * '<S139>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Saturation Fdbk'
 * '<S140>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Sum'
 * '<S141>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Sum Fdbk'
 * '<S142>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tracking Mode'
 * '<S143>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tracking Mode Sum'
 * '<S144>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tsamp - Integral'
 * '<S145>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tsamp - Ngain'
 * '<S146>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/postSat Signal'
 * '<S147>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/preSat Signal'
 * '<S148>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Anti-windup/Disc. Clamping Parallel'
 * '<S149>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone'
 * '<S150>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
 * '<S151>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/D Gain/Disabled'
 * '<S152>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/External Derivative/Disabled'
 * '<S153>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Filter/Disabled'
 * '<S154>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Filter ICs/Disabled'
 * '<S155>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/I Gain/External Parameters'
 * '<S156>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Ideal P Gain/Passthrough'
 * '<S157>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Ideal P Gain Fdbk/Disabled'
 * '<S158>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Integrator/Discrete'
 * '<S159>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Integrator ICs/Internal IC'
 * '<S160>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/N Copy/Disabled wSignal Specification'
 * '<S161>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/N Gain/Disabled'
 * '<S162>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/P Copy/Disabled'
 * '<S163>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Parallel P Gain/External Parameters'
 * '<S164>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Reset Signal/Disabled'
 * '<S165>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Saturation/Enabled'
 * '<S166>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Saturation Fdbk/Disabled'
 * '<S167>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Sum/Sum_PI'
 * '<S168>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Sum Fdbk/Disabled'
 * '<S169>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tracking Mode/Disabled'
 * '<S170>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tracking Mode Sum/Passthrough'
 * '<S171>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tsamp - Integral/TsSignalSpecification'
 * '<S172>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/Tsamp - Ngain/Passthrough'
 * '<S173>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/postSat Signal/Forward_Path'
 * '<S174>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem1/Discrete PID Controller1/preSat Signal/Forward_Path'
 * '<S175>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller'
 * '<S176>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Anti-windup'
 * '<S177>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/D Gain'
 * '<S178>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/External Derivative'
 * '<S179>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Filter'
 * '<S180>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Filter ICs'
 * '<S181>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/I Gain'
 * '<S182>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Ideal P Gain'
 * '<S183>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Ideal P Gain Fdbk'
 * '<S184>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Integrator'
 * '<S185>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Integrator ICs'
 * '<S186>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/N Copy'
 * '<S187>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/N Gain'
 * '<S188>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/P Copy'
 * '<S189>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Parallel P Gain'
 * '<S190>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Reset Signal'
 * '<S191>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Saturation'
 * '<S192>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Saturation Fdbk'
 * '<S193>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Sum'
 * '<S194>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Sum Fdbk'
 * '<S195>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tracking Mode'
 * '<S196>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tracking Mode Sum'
 * '<S197>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tsamp - Integral'
 * '<S198>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tsamp - Ngain'
 * '<S199>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/postSat Signal'
 * '<S200>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/preSat Signal'
 * '<S201>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Anti-windup/Passthrough'
 * '<S202>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/D Gain/Disabled'
 * '<S203>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/External Derivative/Disabled'
 * '<S204>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Filter/Disabled'
 * '<S205>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Filter ICs/Disabled'
 * '<S206>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/I Gain/External Parameters'
 * '<S207>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Ideal P Gain/Passthrough'
 * '<S208>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S209>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Integrator/Discrete'
 * '<S210>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Integrator ICs/Internal IC'
 * '<S211>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/N Copy/Disabled wSignal Specification'
 * '<S212>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/N Gain/Disabled'
 * '<S213>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/P Copy/Disabled'
 * '<S214>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Parallel P Gain/External Parameters'
 * '<S215>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Reset Signal/Disabled'
 * '<S216>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Saturation/Enabled'
 * '<S217>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Saturation Fdbk/Disabled'
 * '<S218>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Sum/Sum_PI'
 * '<S219>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Sum Fdbk/Disabled'
 * '<S220>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tracking Mode/Disabled'
 * '<S221>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tracking Mode Sum/Passthrough'
 * '<S222>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tsamp - Integral/TsSignalSpecification'
 * '<S223>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/Tsamp - Ngain/Passthrough'
 * '<S224>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/postSat Signal/Forward_Path'
 * '<S225>' : 'NLFO_CodeGenerator/FOC_NLFO/Subsystem2/Discrete PID Controller/preSat Signal/Forward_Path'
 */
#endif                                 /* FOC_NLFO_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
