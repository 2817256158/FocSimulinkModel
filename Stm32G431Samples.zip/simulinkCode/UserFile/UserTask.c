#include "UserTask.h"
#include "usbd_cdc_if.h"
#include "FOC_NLFO.h"
#include "arm_math.h"
#include "abz.h"
#include <math.h>
#include "Filter.h"
/* 常量定义 */


/*结构体变量*/
//volatile UART_DataFrame frame;

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim4;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;

/*全局变量*/
int16_t Iabc_Raw[3] = {0};
uint16_t Iabc_Offset[3] = {0x40, 0x1E, 0x00};
uint16_t Iabc_Zero[3] = {0};
float Iabc[3] = {0};
LowPassFilter Iabc_Filter[3];

void UserInit()
{


	/*开启PWM输出*/
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
	__HAL_TIM_MOE_ENABLE(&htim1);
	HAL_TIM_Base_Start(&htim1);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 4000);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 4000);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 4000);

	/*零点对齐*/
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 1838);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 2362);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 2362);

	HAL_Delay(500);
	TIM3->CNT = 0;
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);

	LowPassFilter_Init(&Iabc_Filter[0], 0.1f, 0.0f);
	LowPassFilter_Init(&Iabc_Filter[1], 0.1f, 0.0f);
	LowPassFilter_Init(&Iabc_Filter[2], 0.1f, 0.0f);

	HAL_Delay(100);
	/*开启注入中断采样*/
	HAL_ADCEx_InjectedStart_IT(&hadc1);
	HAL_TIM_Base_Start(&htim4);
	
	/*进入主循环之前进行simulink代码和参数初始化*/
	FOC_NLFO_initialize();
	Cur_Kp = -0.6f;
	Cur_Ki = -5.0f;
	Speed_Kp = -0.0015f;
	Speed_Ki = -0.0018f;
	Gamma = 100000.0F;
	Pll_Kp = 100000.0F;
	Pll_Ki = 1.0E8F;
	
	
}
void UserLoop()
{

}

/*旋钮调速变量*/
volatile uint16_t ADC2_IN = 0;
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{

	Iabc_Raw[0] = (ADC1->JDR1 - Iabc_Offset[0]) - Iabc_Zero[0];
	Iabc_Raw[1] = (ADC1->JDR2 - Iabc_Offset[1]) - Iabc_Zero[1];
	Iabc_Raw[2] = (ADC1->JDR3 - Iabc_Offset[2]) - Iabc_Zero[2];
	ADC2_IN = ADC1->JDR4;
	if(Iabc_Zero[0] == 0)
	{
		Iabc_Zero[0] = Iabc_Raw[0];
		Iabc_Zero[1] = Iabc_Raw[1];
		Iabc_Zero[2] = Iabc_Raw[2];
		Iabc_Raw[0] = 0;
		Iabc_Raw[1] = 0;
		Iabc_Raw[2] = 0;
	}
	Iabc[0] = Iabc_Raw[0]*0.02014f;
	Iabc[1] = Iabc_Raw[1]*0.02014f;
	Iabc[2] = Iabc_Raw[2]*0.02014f;

	
	//编码器获取角度
	// Mech_Theta = Read_Mech_Theta();
	// Mech_Speed = Read_Mech_Speed(Mech_Theta, Uq, 0.1f);
	
	/*simulink模型参数输入接口*/
	Speed_Target = (ADC2_IN / 4096.0f)*8000.0f;//使用旋钮进行调速
	Theta_ele = Theta_Obs;
	Mech_Speed = Speed_Obs;
	PhaseCurrentA = LowPassFilter_Update(&Iabc_Filter[0],Iabc[0]);
	PhaseCurrentB = LowPassFilter_Update(&Iabc_Filter[1],Iabc[1]);
	PhaseCurrentC = LowPassFilter_Update(&Iabc_Filter[2],Iabc[2]);
	/*运行simulink模型*/
	FOC_NLFO_step();
	/*使用simulink输出Ta,Tb,Tc进行PWM输出更新*/
	__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,(uint16_t)Ta);
	__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,(uint16_t)Tb);
	__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,(uint16_t)Tc);
	

	HAL_ADCEx_InjectedStart_IT(hadc);
	// HAL_GPIO_WritePin(GPIOC,GPIO_PIN_10,GPIO_PIN_RESET);
}
