#ifndef _USERTASK_H_
#define _USERTASK_H_

#include "main.h"

#define ENCODER_COUNTS_PER_REV 16384.0f
#define TWO_PI 6.283185307179586f
#define PI 3.141592653589793f
#define ANGLE_DIFF_THRESHOLD 1.0f  /* 约57.3度，用于合理性检查 */
#define DELTA_T 0.00005f           /* 采样时间间隔：50微秒 */

void UserInit();
void UserLoop();

	
#endif