/**
 * @file Filter.c
 * @brief 低通滤波器实现文件
 * 
 * 这个文件实现了一阶IIR低通滤波器。
 * 滤波器公式: y[n] = α * x[n] + (1-α) * y[n-1]
 * 其中α是滤波系数，范围0.0~1.0，值越小滤波效果越强。
 * 
 * 主要功能：
 * 1. 滤波器初始化
 * 2. 实时滤波更新
 * 3. 滤波器参数配置
 * 4. 截止频率到alpha系数的转换
 * 
 * @version 1.0
 * @date 2026-01-19
 */

#include "Filter.h"
#include <math.h>
#include <stddef.h>

/**
 * @brief 初始化低通滤波器
 * @param filter 滤波器指针
 * @param alpha 滤波系数 (0.0 ~ 1.0)，值越小滤波效果越强
 * @param initial_value 初始值
 */
void LowPassFilter_Init(LowPassFilter* filter, float alpha, float initial_value)
{
    if (filter == NULL) {
        return;
    }
    
    /* 限制alpha在有效范围内 */
    if (alpha < 0.0f) {
        alpha = 0.0f;
    } else if (alpha > 1.0f) {
        alpha = 1.0f;
    }
    
    filter->alpha = alpha;
    filter->prev_output = initial_value;
    filter->initialized = 1;
}

/**
 * @brief 低通滤波器更新函数
 * @param filter 滤波器指针
 * @param input 输入值
 * @return 滤波后的输出值
 */
float LowPassFilter_Update(LowPassFilter* filter, float input)
{
    float output;
    
    if (filter == NULL) {
        return input;
    }
    
    /* 如果未初始化，则初始化 */
    if (!filter->initialized) {
        filter->prev_output = input;
        filter->initialized = 1;
        return input;
    }
    
    /* 一阶IIR低通滤波器: y[n] = α * x[n] + (1-α) * y[n-1] */
    output = filter->alpha * input + (1.0f - filter->alpha) * filter->prev_output;
    
    /* 更新上一次的输出值 */
    filter->prev_output = output;
    
    return output;
}

/**
 * @brief 重置低通滤波器
 * @param filter 滤波器指针
 * @param value 重置后的值
 */
void LowPassFilter_Reset(LowPassFilter* filter, float value)
{
    if (filter == NULL) {
        return;
    }
    
    filter->prev_output = value;
    filter->initialized = 1;
}

/**
 * @brief 设置低通滤波器系数
 * @param filter 滤波器指针
 * @param alpha 新的滤波系数 (0.0 ~ 1.0)
 */
void LowPassFilter_SetAlpha(LowPassFilter* filter, float alpha)
{
    if (filter == NULL) {
        return;
    }
    
    /* 限制alpha在有效范围内 */
    if (alpha < 0.0f) {
        alpha = 0.0f;
    } else if (alpha > 1.0f) {
        alpha = 1.0f;
    }
    
    filter->alpha = alpha;
}

/**
 * @brief 获取当前滤波器输出值
 * @param filter 滤波器指针
 * @return 当前输出值
 */
float LowPassFilter_GetOutput(LowPassFilter* filter)
{
    if (filter == NULL || !filter->initialized) {
        return 0.0f;
    }
    
    return filter->prev_output;
}

/**
 * @brief 计算截止频率对应的alpha系数
 * @param cutoff_freq 截止频率 (Hz)
 * @param sample_freq 采样频率 (Hz)
 * @return 计算得到的alpha系数
 * 
 * 注意：此函数需要math.h库支持
 * 公式：α = 1 - exp(-2π * fc / fs)
 */
float LowPassFilter_CalculateAlpha(float cutoff_freq, float sample_freq)
{
    float alpha;
    
    if (cutoff_freq <= 0.0f || sample_freq <= 0.0f) {
        return 1.0f;  /* 无效参数，返回无滤波效果 */
    }
    
    if (cutoff_freq >= sample_freq / 2.0f) {
        return 1.0f;  /* 截止频率过高，返回无滤波效果 */
    }
    
    /* 计算alpha系数 */
    alpha = 1.0f - expf(-2.0f * 3.14159265358979323846f * cutoff_freq / sample_freq);
    
    return alpha;
}

/**
 * @brief 低通滤波器相位滞后补偿
 * @param filter 滤波器指针
 * @param input 输入值
 * @param compensation_gain 补偿增益（通常为0.0~1.0）
 * @return 相位补偿后的输出值
 * 
 * 这个函数对低通滤波器的输出进行相位滞后补偿。
 * 补偿方法：y_comp = y_filtered + compensation_gain * (y_filtered - y_previous)
 * 其中y_filtered是当前滤波输出，y_previous是上一次滤波输出。
 * 补偿增益越大，相位超前效果越强。
 * 
 * 注意：这个函数会更新滤波器的状态，所以不应该与LowPassFilter_Update()同时使用。
 * 如果需要同时获取滤波输出和补偿输出，应该先调用LowPassFilter_Update()，
 * 然后使用LowPassFilter_GetOutput()获取滤波输出，再计算补偿。
 */
float LowPassFilter_PhaseCompensation(LowPassFilter* filter, float input, float compensation_gain)
{
    float filtered_output;
    float previous_output;
    float compensated_output;
    
    if (filter == NULL) {
        return input;
    }
    
    /* 保存上一次的输出值 */
    previous_output = filter->prev_output;
    
    /* 执行滤波更新 */
    filtered_output = LowPassFilter_Update(filter, input);
    
    /* 如果未初始化或补偿增益为0，直接返回滤波输出 */
    if (!filter->initialized || compensation_gain == 0.0f) {
        return filtered_output;
    }
    
    /* 限制补偿增益在合理范围内 */
    if (compensation_gain < 0.0f) {
        compensation_gain = 0.0f;
    } else if (compensation_gain > 2.0f) {
        compensation_gain = 2.0f;  /* 允许稍大的补偿增益，但限制在合理范围 */
    }
    
    /* 计算相位补偿输出：y_comp = y_filtered + gain * (y_filtered - y_previous) */
    compensated_output = filtered_output + compensation_gain * (filtered_output - previous_output);
    
    return compensated_output;
}

/**
 * @brief 计算基于滤波器参数的相位补偿增益
 * @param alpha 滤波器alpha系数
 * @param desired_phase_advance 期望的相位超前角度（度）
 * @return 计算得到的补偿增益
 * 
 * 这个函数根据滤波器参数和期望的相位超前角度计算补偿增益。
 * 对于一阶低通滤波器，相位滞后约为：φ = -arctan(ωτ)
 * 其中ω是角频率，τ是时间常数。
 * 补偿增益k可以通过以下公式近似计算：k ≈ tan(φ_desired) / (ωτ)
 * 其中φ_desired是期望的相位超前角度（弧度）。
 * 
 * 简化公式：k ≈ (desired_phase_advance * π / 180) / (1/α - 1)
 * 其中α是滤波器系数。
 * 
 * 注意：这个公式是近似计算，实际效果可能需要调整。
 */
float LowPassFilter_CalculateCompensationGain(float alpha, float desired_phase_advance)
{
    float phase_rad;
    float compensation_gain;
    
    /* 参数检查 */
    if (alpha <= 0.0f || alpha > 1.0f) {
        return 0.0f;  /* 无效的alpha系数 */
    }
    
    if (desired_phase_advance <= 0.0f) {
        return 0.0f;  /* 不需要相位超前 */
    }
    
    if (desired_phase_advance > 90.0f) {
        desired_phase_advance = 90.0f;  /* 限制最大相位超前为90度 */
    }
    
    /* 将角度转换为弧度 */
    phase_rad = desired_phase_advance * 3.14159265358979323846f / 180.0f;
    
    /* 计算时间常数τ（近似） */
    /* 对于离散时间一阶低通滤波器：α = 1 - exp(-Δt/τ) */
    /* 所以 τ ≈ -Δt / ln(1-α) */
    /* 简化计算：补偿增益 k ≈ tan(φ) * (1-α)/α */
    
    /* 使用简化公式计算补偿增益 */
    if (alpha < 1.0f) {
        compensation_gain = tanf(phase_rad) * (1.0f - alpha) / alpha;
    } else {
        compensation_gain = 0.0f;  /* α=1时无滤波，不需要补偿 */
    }
    
    /* 限制补偿增益在合理范围内 */
    if (compensation_gain < 0.0f) {
        compensation_gain = 0.0f;
    } else if (compensation_gain > 2.0f) {
        compensation_gain = 2.0f;
    }
    
    return compensation_gain;
}
