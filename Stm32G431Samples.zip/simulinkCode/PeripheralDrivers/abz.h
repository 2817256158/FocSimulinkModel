#ifndef _ABZ_H_
#define _ABZ_H_

#include "main.h"
#include "UserTask.h"

#define TIM_HANDLE TIM3

#define DIR 0
#define Rad_EncoderNum 16384


float Read_Mech_Theta(void);
float Read_Mech_Speed(float Mech_Theta, float Uq, float Alpha);


#endif