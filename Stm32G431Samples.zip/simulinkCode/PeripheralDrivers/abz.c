#include "abz.h"

float Read_Mech_Theta(void)
{
    uint16_t EncoderNum = (TIM3->CNT) % Rad_EncoderNum;
    float Theta = (EncoderNum / ENCODER_COUNTS_PER_REV) * TWO_PI;

    //编码器反装矫正
    if(DIR)
    {
        Theta = TWO_PI - Theta;
        if(Theta < 0)Theta += TWO_PI;
    }

    return Theta;
}
float Read_Mech_Speed(float Mech_Theta, float Uq, float Alpha)
{
    static float Mech_Theta_Prv = 0.0f;
    static float Mech_Speed_Prv = 0.0f;
    static float speed_window[10] = {0.0f};  /* 滑动窗口，存储最近10个速度值 */
    static int window_index = 0;             /* 当前窗口索引 */
    static int window_filled = 0;            /* 窗口是否已填满标志 */
    float Mech_Speed = 0.0f;
    float filtered_speed = 0.0f;
    int i;

    float Mech_Theta_Delt = Mech_Theta - Mech_Theta_Prv;
	// 处理角度跨越0-2π边界的情况
	if (Mech_Theta_Delt > PI)
	{
		Mech_Theta_Delt -= TWO_PI;
	}
	else if (Mech_Theta_Delt < -PI)
	{
		Mech_Theta_Delt += TWO_PI;
	}

	if (Uq >= 0 && Mech_Theta_Delt < -ANGLE_DIFF_THRESHOLD)
	{
		Mech_Theta_Delt += TWO_PI;
	}
	else if (Uq < 0 && Mech_Theta_Delt > ANGLE_DIFF_THRESHOLD)
	{
		Mech_Theta_Delt -= TWO_PI;
	}

	Mech_Theta_Prv = Mech_Theta;

	//Mech_Speed =  ((Mech_Theta_Delt * 20000.0f) * 60.0f) / TWO_PI;
    Mech_Speed =  Mech_Theta_Delt * 190986.091f;
    
    /* 应用Alpha滤波（原有的低通滤波） */
    if(Alpha > 0.0f && Alpha < 1.0f)
    {
        Mech_Speed = Mech_Speed_Prv * Alpha + Mech_Speed * (1.0f-Alpha);
    }

    /* 更新滑动窗口 */
    speed_window[window_index] = Mech_Speed;
    window_index++;
    if (window_index >= 10)
    {
        window_index = 0;
        window_filled = 1;  /* 窗口已填满 */
    }
    
    /* 计算滑动窗口平均值 */
    filtered_speed = 0.0f;
    if (window_filled)
    {
        /* 窗口已填满，计算10个值的平均值 */
        for (i = 0; i < 10; i++)
        {
            filtered_speed += speed_window[i];
        }
        filtered_speed /= 10.0f;
    }
    else
    {
        /* 窗口未填满，计算已填充值的平均值 */
        for (i = 0; i < window_index; i++)
        {
            filtered_speed += speed_window[i];
        }
        filtered_speed /= (float)window_index;
    }

    Mech_Speed_Prv = filtered_speed;  /* 更新上一次的速度值为滤波后的值 */

    return filtered_speed;

}
